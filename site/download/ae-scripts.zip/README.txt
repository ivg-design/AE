IVG Toolkit - After Effects scripts (MIT)
==========================================

A) IVGD Command Bar (recommended - keeps your Window menu clean)
   1. Copy "IVGD Command Bar.jsx" AND the whole "ivg-scripts" folder into:
        After Effects > Scripts > ScriptUI Panels
   2. Restart After Effects (or File > Scripts > Rescan Script Folder).
   3. Open Window > IVGD Command Bar.jsx - a dockable, resizable toolbar.
      Hover a button for name + usage. Elast-o-matic: hold Cmd/Ctrl for the
      alternate (regular bounce) variant.

B) Classic: drag any .jsx from ivg-scripts/<category>/ into Scripts or
   Scripts > ScriptUI Panels.

SYNC-O-TRON TEMPLATE: ivg-scripts/projects/Sync-o-tron.aep is imported
automatically on first launch if no AUDIO REACTOR comp exists.

Enable "Allow Scripts to Write Files and Access Network" in
Preferences > Scripting & Expressions for tools that write presets.

Docs & updates: https://github.com/ivg-design/ae
