Build-a-Bar bundle — 33 scripts (MIT)
=========================================================

INSTALL
  1. Copy "Build-a-Bar.jsx" AND the whole "ivg-scripts" folder into:
       After Effects > Scripts > ScriptUI Panels
  2. Restart After Effects (or File > Scripts > Rescan Script Folder).
  3. Open Window > Build-a-Bar.jsx — a dockable, resizable toolbar
     with one icon button per script.

Only the command bar appears in the Window menu; your scripts live in the
ivg-scripts subfolder and are launched by the bar.

INCLUDED
  - 2-3_IK_Rigger v1.0.0 (animation)
  - Limb-a-tron v2.7.0 (animation)
  - Linearizer v1.5.8 (animation)
  - PathMaster v2.0.2 (animation)
  - Guiderator v2.0.0 (composition)
  - Slidotron_16x9 v2.0.1 (composition)
  - Slidotron_9x16 v2.0.2 (composition)
  - BurstMate v2.0.1 (effects)
  - ChromaBlenderizer v2.3.1 (effects)
  - sfxMaster v2.0.1 (effects)
  - Sync-o-tron v2.1.4 (effects)
  - Elast-o-matic v1.0.0 (keyframes)
  - KeyBot v2.0.1 (keyframes)
  - KeyCloneMatic v2.0.1 (keyframes)
  - Valuatron v2.0.1 (keyframes)
  - Controllerizer v1.0.0 (layers)
  - NullBot v2.0.0 (layers)
  - Opac-o-bot v1.0.0 (layers)
  - OrderMaster v2.0.1 (layers)
  - Parent-o-bot v2.0.2 (layers)
  - Rectangulator v2.1.6 (layers)
  - Reseterator v1.0.0 (layers)
  - SubtitleForge v2.0.1 (layers)
  - TextMate v2.0.0 (layers)
  - TimeWarp-a-tron v2.0.1 (layers)
  - Centralizer v2.1.0 (paths)
  - Distributron v1.1.2 (paths)
  - Originator v2.0.0 (paths)
  - Trace-o-matic v2.0.1 (paths)
  - VertexMaster v2.0.2 (paths)
  - Iteratron v2.0.1 (utilities)
  - RandoMatic v2.0.0 (utilities)
  - Triminator v2.0.0 (utilities)
